# playwright-core

This package contains the no-browser flavor of [Playwright](http://github.com/microsoft/playwright).
